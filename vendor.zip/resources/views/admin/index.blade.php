@extends('layouts.admin')

@section('content')
<div class="card">
    <div class="card-body">
        Dwi Yuni Rahman
    </div>
</div>
@endsection
