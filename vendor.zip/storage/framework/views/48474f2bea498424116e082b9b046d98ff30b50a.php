<?php $__env->startSection('title'); ?>
    Toko Kita | Kategori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h5>Semua Kategori</h5>
                    <div class="row">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 mb-3">
                                <a href="<?php echo e(url('show-category/'.$item_k->slug)); ?>">
                                <div class="card">
                                    <div class="card-body">
                                        <img src="<?php echo e(asset('assets/uploads/kategori/'.$item_k->image)); ?>" alt="item" class="kat-img mb-2">
                                        <h5><?php echo e($item_k->name); ?></h5>
                                        <p>
                                            <?php echo e($item_k->description); ?>

                                        </p>
                                    </div>
                                </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/customer/kategori.blade.php ENDPATH**/ ?>