<?php $__env->startSection('title'); ?>
    Toko Kita | <?php echo e($produk->nama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card shadow mt-3 data_produk">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 border-right">
                        <img src="<?php echo e(asset('assets/uploads/produk/'.$produk->image)); ?>" alt="produk" class="w-50">
                    </div>
                    <div class="col-md-8">
                        <h2 class="mb-0">
                            <?php echo e($produk->nama); ?>

                        </h2>

                        <hr>

                        <label for="" class="me-3">Harga : <?php echo e($produk->harga); ?></label>
                        <p class="mt-3">
                            <?php echo e($produk->deskripsi_singkat); ?>

                        </p>

                        <hr>
                        <?php if($produk->qty > 0): ?>
                            <label for="" class="badge bg-success">Stok Tersedia</label>
                        <?php else: ?>
                            <label for="" class="badge bg-danger">Stok Tidak Tersedia</label>
                        <?php endif; ?>

                        <div class="row mt-2">
                            <div class="col-md-3">
                                <input type="hidden" name="" value="<?php echo e($produk->id); ?>" class="produk_id">
                                <label for="">Jumlah</label>
                                <div class="input-group text-center mb-3" style="width:130px">
                                    <button class="input-group-text decrement-btn">-</button>
                                    <input type="text" name="jumlah"  class="form-control qty-input text-center" value="1">
                                    <button class="input-group-text increment-btn">+</button>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <br>
                                <?php if($produk->qty > 0): ?>
                                    <button type="button" class="btn btn-success me-3 float-start addCart">Tambah ke Keranjang</button>
                                <?php endif; ?>


                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/customer/produk/view.blade.php ENDPATH**/ ?>