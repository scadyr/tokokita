<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
        
        <div class="sidebar-brand-icon">
            <i class="fas fa-store"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Toko Kita</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
        <a class="nav-link" href="/dashboard">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php echo e(Request::is('kategori') || Request::is('add-kategori')  ? 'active' : ''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-database"></i>
            <span>Kategori</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                
                <a class="collapse-item <?php echo e(Request::is('kategori') ? 'active' : ''); ?>" href="<?php echo e(url('kategori')); ?>">Data Kategori</a>
                <a class="collapse-item <?php echo e(Request::is('add-kategori') ? 'active' : ''); ?>" href="<?php echo e(url('add-kategori')); ?>">Tambah Kategori</a>
            </div>
        </div>
    </li>

    

    <li class="nav-item <?php echo e(Request::is('produk') || Request::is('add-produk')  ? 'active' : ''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-database"></i>
            <span>Produk</span>
        </a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                
                <a class="collapse-item <?php echo e(Request::is('produk') ? 'active' : ''); ?>" href="<?php echo e(url('produk')); ?>">Data Produk</a>
                <a class="collapse-item <?php echo e(Request::is('add-produk') ? 'active' : ''); ?>" href="<?php echo e(url('add-produk')); ?>">Tambah Produk</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    

</ul>
<?php /**PATH C:\xampp74\applications\tokokita\resources\views/layouts/incl/sidebar.blade.php ENDPATH**/ ?>