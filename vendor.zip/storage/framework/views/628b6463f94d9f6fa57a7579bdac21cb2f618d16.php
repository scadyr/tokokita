<?php $__env->startSection('title'); ?>
    Selamat Datang di Toko Kita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.incl.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-4">
        <div class="container">
            <h4>Produk Kami</h4>
            <div class="row">
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(url('produk/'.$item->id)); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/uploads/produk/'.$item->image)); ?>" alt="" class="produk-img">
                            <div class="card-body">
                                <h5><?php echo e($item->nama); ?></h5>
                                <p><?php echo e($item->harga_jual); ?></p>
                            </div>
                        </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/customer/index.blade.php ENDPATH**/ ?>