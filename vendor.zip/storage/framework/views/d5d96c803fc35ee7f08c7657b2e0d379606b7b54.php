<?php $__env->startSection('title'); ?>
    Keranjang Belanja
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card shadow mt-3 data_produk">
            <div class="card-body">
                <?php
                    $total = 0;
                ?>
                <?php $__currentLoopData = $datacart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-2">
                            <img src="<?php echo e(asset('assets/uploads/produk/'.$item->produk->image)); ?>" alt="produk" class="w-50">
                        </div>
                        <div class="col-md-4">
                            <h5 class="mb-0">
                                <?php echo e($item->produk->nama); ?>

                            </h5>
                        </div>
                        <div class="col-md-2">
                            <h5>Rp. <?php echo e($item->produk->harga_jual); ?></h5>
                        </div>
                        <div class="col-md-3">
                            <input type="hidden" name="" value="<?php echo e($item->produk->id); ?>" class="produk_id">
                            <?php if($item->produk->qty > $item->produk_qty): ?>
                                <label for="">Jumlah</label>
                                <div class="input-group text-center mb-3" style="width:130px">
                                    <button class="input-group-text decrement-btn">-</button>
                                    <input type="text" name="jumlah" class="form-control qty-input text-center" value="<?php echo e($item->produk_qty); ?>">
                                    <button class="input-group-text increment-btn">+</button>
                                </div>
                                <?php
                                    $total += $item->produk->harga_jual * $item->produk_qty;
                                ?>
                            <?php else: ?>
                                Stok Habis
                            <?php endif; ?>
                        </div>
                        <div class="col-md-1 mb-3">

                            <button type="button" class="btn btn-danger me-3 float-start delete-item">Hapus</button>
                            
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="card-footer">
                <h6>Total Price : Rp <?php echo e($total); ?></h6>

                <a href="<?php echo e(url('checkout')); ?>" class="btn btn-outline-success float-end">Checkout</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/customer/cart.blade.php ENDPATH**/ ?>