<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Toko Kita 2022</span>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp74\applications\tokokita\resources\views/layouts/incl/adminfooter.blade.php ENDPATH**/ ?>