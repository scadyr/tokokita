<?php $__env->startSection('title'); ?>
    Toko Kita | Produk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-4">
        <div class="container">
            <h5><?php echo e($kategori->name); ?></h5>
            <div class="row">
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <a href="<?php echo e(url('show-category/'.$kategori->slug.'/'.$item->id)); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/uploads/produk/'.$item->image)); ?>" alt="" class="produk-img">
                            <div class="card-body">
                                <h5><?php echo e($item->nama); ?></h5>
                                <p><?php echo e($item->harga_jual); ?></p>
                            </div>
                        </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/customer/produk/index.blade.php ENDPATH**/ ?>