<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1>Form Tambah Produk</h1>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('update-produk/'.$produk->id )); ?>" method="POST" enctype="multipart/form-data">
            <div class="row">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-md-12 mb-3">
                    <select class="form-control">
                        
                            <option value=""><?php echo e($produk->kategori->name); ?></option>
                        
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Nama Produk</label>
                    <input type="text" class="form-control" name="nama" value="<?php echo e($produk->nama); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Deskripsi Singkat</label>
                    <input type="text" class="form-control" name="deskripsi_singkat" value="<?php echo e($produk->deskripsi_singkat); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label for="">Deskripsi</label>
                    <textarea name="deskripsi" rows="3" class="form-control"><?php echo e($produk->deskripsi); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Harga</label>
                    <input type="number" class="form-control" name="harga" value="<?php echo e($produk->harga); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Harga Jual</label>
                    <input type="number" class="form-control" name="harga_jual" value="<?php echo e($produk->harga_jual); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Jumlah</label>
                    <input type="number" class="form-control" name="qty" value="<?php echo e($produk->qty); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Pajak</label>
                    <input type="number" class="form-control" name="tax" value="<?php echo e($produk->tax); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Status</label>
                    <input type="checkbox" name="status" <?php echo e($produk->status == "1" ? "checked" : ""); ?>>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Trending</label>
                    <input type="checkbox" name="trending" <?php echo e($produk->trending == "1" ? "checked" : ""); ?>>
                </div>
                <div class="col-md-12 mb-3">
                    <label for="">Meta Title</label>
                    <input type="text" name="meta_title" class="form-control" value="<?php echo e($produk->meta_title); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Meta Keywords</label>
                    <textarea name="meta_keywords" rows="3" class="form-control"><?php echo e($produk->meta_keywords); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Meta Description</label>
                    <textarea name="meta_description" rows="3" class="form-control"><?php echo e($produk->meta_description); ?></textarea>
                </div>
                <?php if($produk->image): ?>
                    <img src="<?php echo e(asset('assets/uploads/produk/'.$produk->image)); ?>" alt="produk image">
                <?php endif; ?>
                <div class="col-md-12 mb-3">
                    <input type="file" name="image" class="form-control">
                </div>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/admin/produk/edit.blade.php ENDPATH**/ ?>