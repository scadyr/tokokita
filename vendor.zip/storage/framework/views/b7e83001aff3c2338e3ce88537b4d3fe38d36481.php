<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4>Produk Data</h4>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Harga Jual</th>
                    <th>Kategori</th>
                    <th>Gambar</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                
                <?php if($produk == ""): ?>
                    <tr>
                        <td colspan="5"><?php echo e($produk); ?></td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->harga); ?></td>
                            <td><?php echo e($item->harga_jual); ?></td>
                            <td><?php echo e($item->kategori->name); ?></td>
                            <td>
                                <img src="<?php echo e(asset('assets/uploads/produk/'.$item->image)); ?>" alt="image" class="kat-img">
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(url('edit-produk/'.$item->id)); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(url('delete-produk/'.$item->id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\applications\tokokita\resources\views/admin/produk/index.blade.php ENDPATH**/ ?>