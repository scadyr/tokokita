<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    

    <!-- Custom fonts for this template-->
    
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    
    <style>
        a {
            text-decoration: none !important;
        }
    </style>

    <link href="<?php echo e(asset('frontend/css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/bootstrap5.css')); ?>" rel="stylesheet">
</head>
<body id="page-top">
    <?php echo $__env->make('layouts.incl.custnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div id="content">
        
            
        

        
        
            <?php echo $__env->yieldContent('content'); ?>
        
        
    </div>
    

    <!-- Scripts -->
    


    

    <!-- Core plugin JavaScript-->
    

    <!-- Custom scripts for all pages-->
    

    <!-- Bootstrap core JavaScript-->
    <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
    
    <script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('frontend/js/custom.js')); ?>" defer></script>


    
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php if(session('status')): ?>
        <script>
            // swal("","success");
            swal({
                title: "",
                text: "<?php echo e(session('status')); ?>",
                icon: "success",
            });
        </script>
    <?php endif; ?>

    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp74\applications\tokokita\resources\views/layouts/customer.blade.php ENDPATH**/ ?>