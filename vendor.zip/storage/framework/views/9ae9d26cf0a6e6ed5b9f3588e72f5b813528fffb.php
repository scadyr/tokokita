<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('frontend/admin/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('frontend/admin/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/admin/css/custom.css')); ?>" rel="stylesheet">
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        
        <?php echo $__env->make('layouts.incl.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <div id="content-wrapper" class="d-flex flex-column">

            
            <div id="content">
                
                    <?php echo $__env->make('layouts.incl.adminnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                

                
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                
            </div>
            

            
            <?php echo $__env->make('layouts.incl.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

        </div>
        
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('frontend/admin/js/bootstrap.bundle.min.js')); ?>" defer></script>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('frontend/admin/vendor/jquery/jquery.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('frontend/admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>" defer></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('frontend/admin/vendor/jquery-easing/jquery.easing.min.js')); ?>" defer></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('frontend/admin/js/sb-admin-2.min.js')); ?>" defer></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(asset('frontend/admin/vendor/chart.js/Chart.min.js')); ?>" defer></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('frontend/admin/js/demo/chart-area-demo.js')); ?>" defer></script>
    <script src="<?php echo e(asset('frontend/admin/js/demo/chart-pie-demo.js')); ?>" defer></script>

    
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php if(session('status')): ?>
        <script>
            // swal("","success");
            swal({
                title: "",
                text: "<?php echo e(session('status')); ?>",
                icon: "success",
            });
        </script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp74\applications\tokokita\resources\views/layouts/admin.blade.php ENDPATH**/ ?>